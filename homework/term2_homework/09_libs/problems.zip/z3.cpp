#include <SFML/Graphics.hpp>
#include <cmath>

int main()
{

    sf::RenderWindow window(sf::VideoMode(800, 600), "Кружок, двигающийся по окружности");

    window.setFramerateLimit(60);

    sf::CircleShape circle(30.f);
    
    circle.setFillColor(sf::Color::Green);

    float centerX = 400, centerY = 300; 
    float radius = 200; 
    float angle = 0; 

    while (window.isOpen())
    {

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        
        circle.setPosition(centerX + radius * cos(angle) - circle.getRadius(),
                           centerY + radius * sin(angle) - circle.getRadius());

        
        angle += 0.02;

        
        window.clear();

        
        window.draw(circle);


        window.display();
    }

    return 0;
}
